#include "ej5-imgproc.h"

/**
 * \fn void procesar_imagen(unsigned char * ImgOriginal, unsigned char * ImgResultado, int ancho, int alto)
 * \brief Reduce una imagen a la mitad de su tamaño
 * \return Nada
 * \author Ignacio Bonelli
 * \date 25.10.2013
 */


void	procesar_imagen(unsigned char * ImgOriginal, unsigned char * ImgResultado, int ancho, int alto)
{
	int fil1,col1;
	int fil2,col2;
	int ancho2 = (int) ancho/2;

	fil2=0; col2=0;

	for (fil1=0; fil1 < (alto -1) ; fil1=fil1+2)
		for (col1=0; col1 < (ancho -1); col1=col1+2) {
			*(ImgResultado+fil2*ancho+col2) = (unsigned char) (( (long)*(ImgOriginal+fil1*ancho+col1) +
				(long) *(ImgOriginal+fil1*ancho+col1+1) + (long)*(ImgOriginal+(fil1+1)*ancho+col1) +
				(long) *(ImgOriginal+(fil1+1)*ancho+col1+1) )/4 );

			if(col2 < (ancho2 -1)) col2++;
			else { col2=0; fil2++; }
		}

	return;
}

