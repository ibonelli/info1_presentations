#include "ej5-imgproc.h"

/**
 * \fn void procesar_imagen(unsigned char * ImgOriginal, unsigned char * ImgResultado, int ancho, int alto)
 * \brief Difumina una imagen
 * \return Nada
 * \author Ignacio Bonelli
 * \date 25.10.2013
 */


void	procesar_imagen(unsigned char * ImgOriginal, unsigned char * ImgResultado, int ancho, int alto)
{
	int fil1,col1;

	for (fil1=0; fil1 < (alto -1) ; fil1++)
		for (col1=0; col1 < (ancho -1); col1++) {
			*(ImgResultado+(fil1+1)*ancho+col1+1) = (unsigned char) ((
				(long)*(ImgOriginal+fil1*ancho+col1) +
				(long) *(ImgOriginal+fil1*ancho+col1+1) + (long) *(ImgOriginal+fil1*ancho+col1+2) + 
				(long) *(ImgOriginal+(fil1+1)*ancho+col1) + 
				(long) *(ImgOriginal+(fil1+1)*ancho+col1+1) + (long) *(ImgOriginal+(fil1+1)*ancho+col1+2) +
				(long) *(ImgOriginal+(fil1+2)*ancho+col1) + 
				(long) *(ImgOriginal+(fil1+2)*ancho+col1+1) + (long) *(ImgOriginal+(fil1+2)*ancho+col1+2)
				)/9 );
		}

	return;
}


