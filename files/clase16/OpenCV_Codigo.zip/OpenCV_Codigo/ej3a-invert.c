/*
 * Inverting the Image
 * 
 * From: http://opencv.wikispaces.com/4%29+Inverting+the+Image
 * Compile: gcc -oej4 ej4-invert.c -g -ggdb `pkg-config --cflags --libs opencv` -Wall
 * 
 * Cargamos una imagen como en el ej1-jpg.c
 * Obtenemos las propiedades de la imagen (height, width, channel, step, date)
 * Para invertir la imagen debemos leer los valores de cada pixel y canal (si está en RGB son 3 ciclos).
 * Dentro del ciclo mas interno cambiamos cada pixel de la imagen a su valor opuesto (pixel - 255).
 * Finalmente mostramos la imagen con la funcion cvShowImage() de highgui.
 * Esperamos una tecla culquiera y liberamos los recursos.
 * Nota: Si la imagen es RGB se asume que los canales tienen orden BGR (inverso).
 */

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <cv.h>
#include <highgui.h>
 
 
int main(int argc, char *argv[])
{
  IplImage* img = 0;
  int height,width,step;
  uchar *data;
  int i,j;
 
  // load an image
  img=cvLoadImage("lenna.jpeg",0);
  if(!img){
    printf("Could not load image file: %s\n",argv[1]);
    exit(0);
  }
 
  // get the image data
  height    = img->height;
  width     = img->width;
  step      = img->widthStep;
  data      = (uchar *)img->imageData;
  printf("Processing a %dx%d image with step %d\n",height,width,step);
 
  // create a window
  cvNamedWindow("example2", CV_WINDOW_AUTOSIZE);
  cvMoveWindow("example2", 100, 100);    // to move the window to position 100 100.
 
  // invert the image
  for(i=0;i<height;i++)
     for(j=0;j<width;j++)
        data[i*step+j]=255-data[i*step+j];    //inverting the image
 
  // show the image
  cvShowImage("example2", img );
 
  // wait for a key
  cvWaitKey(0);
 
  // release the image
  cvReleaseImage(&img );
  cvDestroyWindow("example2");
  return 0;
}
