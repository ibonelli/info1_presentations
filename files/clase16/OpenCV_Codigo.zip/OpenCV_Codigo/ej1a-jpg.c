/**
 * \file imgproc
 * \brief Programa sencillo para abrir una imagen y presentarla en una ventana
 * \details Utilizamos la biblioteca Opencv para abrir la imagen aprovechando 
 * sus funciones independientes del tipo de archivo, y también para crear una
 * ventana sencilla (sin menú), para presentarla en la GUI del sistema operativo
 * que se tenga (Linux, Windows, o MAC OS).
 * Este programa compila en Linux, mediante el comando siguiente:
 * gcc -o img img.c `pkg-config --cflags --libs opencv` -g -ggdb -Wall 
 * \author Alejandro Furfaro. afurfaro@electron.frba.utn.edu.ar
 * 
 * Muy similar a http://opencv.wikispaces.com/3%29+First+Sample+Program
 * 
 * \date 12.05.2011
*/ 

#include <cv.h>
#include <highgui.h>

int main()
{
  //Instancia una estructura IplImage, definida en openCV para 
  //cargar la información de la imagen origen
  IplImage *image = cvLoadImage("./lenna.jpeg",0);
  //Creamos una ventana llamada "ejemplo1", autoajustable al 
  //tamaño de la imagen que le vamos a colocar dentro
  cvNamedWindow("ejemplo1",CV_WINDOW_AUTOSIZE);
  //Movemos la ventana al pixel 100 de la fila 100
  cvMoveWindow("ejemplo1",100,100);
  //Mostramos la imagen leída en la ventana creada
  cvShowImage("ejemplo1", image);
  //Esperamos que el usuario presione cualquier tecla...
  cvWaitKey(1000);
  //Liberamos los recursos utilizados
  cvReleaseImage(&image);
  cvDestroyWindow("ejemplo1");
  //Terminamos el programa
  return 0;
}
