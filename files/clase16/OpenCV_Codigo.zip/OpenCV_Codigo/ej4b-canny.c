// cany.cpp: define el punto de entrada de la aplicaci�n de consola.
// Similar a: http://opencv.wikispaces.com/4%29+Inverting+the+Image
// Compilar: gcc -oej4b ej4-canny.c -g -ggdb `pkg-config --cflags --libs opencv` -Wall

#include <cv.h>
#include <highgui.h>
#include <stdio.h>

double threshold1, threshold2;
int level1, level2, aperture;
IplImage *imgOrig, *imgBordes;

void on_trackbar(int pos)
{
	threshold1 = (double) level1;
	threshold2 = (double) level2;
	cvCanny(imgOrig, imgBordes, threshold1, threshold2, aperture);
	cvShowImage("Bordes",imgBordes);
}

int main()
{
	threshold1=15;
	threshold2=100;
	aperture=3;

	cvNamedWindow("Original",CV_WINDOW_AUTOSIZE);
	imgOrig = cvLoadImage("lenna.jpeg",0); // La leo en escala de grises por que el cvCanny solo funciona con imagenes en escala de Grices
	imgBordes =  cvCreateImage( cvGetSize(imgOrig), IPL_DEPTH_8U, 1 );
	cvShowImage("Original",imgOrig);

	cvNamedWindow("Bordes",CV_WINDOW_AUTOSIZE);
    cvCreateTrackbar("First threshold", "Bordes", &level1, 256, on_trackbar );
    cvCreateTrackbar("Second threshold", "Bordes", &level2, 256, on_trackbar );

    on_trackbar(0);

	// wait for a key
	cvWaitKey(0);
	// Esta version de cierre no funciona
	// while( cvWaitKey(100) != 27); //Sale con esc

	// release the image
	cvReleaseImage(&imgOrig);
	cvReleaseImage(&imgBordes);
	cvDestroyWindow("Original");
	cvDestroyWindow("Bordes");

	return 0;
}

