#include "ej5-imgproc.h"

/**
 * \fn void procesar_imagen(unsigned char * ImgOriginal, unsigned char * ImgResultado, int ancho, int alto)
 * \brief Difumina una imagen. Dependiendo del radio el grado de difuminación.
 * \return Nada
 * \author Ignacio Bonelli
 * \date 25.10.2013
 */


void	procesar_imagen(unsigned char * ImgOriginal, unsigned char * ImgResultado, int ancho, int alto)
{
	int x,y;
	long total;
	int ky, kx ,radius=3;

	for (y=0; y < (alto -1) ; y++)
		for (x=0; x < (ancho -1); x++) {
            total = 0;
            for (ky = -radius; ky <= radius; ++ky)
                for (kx = -radius; kx <= radius; ++kx)
                    total += *(ImgOriginal+x+kx+(y+ky)*ancho);
            *(ImgResultado+x+y*ancho) = total / ((radius * 2 + 1)*(radius * 2 + 1));
		}

	return;
}


