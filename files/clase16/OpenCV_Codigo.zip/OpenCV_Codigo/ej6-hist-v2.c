/*
 * De: http://docs.opencv.org/doc/tutorials/imgproc/histograms/histogram_equalization/histogram_equalization.html
 * Y: http://docs.opencv.org/modules/imgproc/doc/histograms.html#calchist
 * 
 * Solo parece trabajar bien en CPP... No logré pasarlo a C
 * Las funciones parecen tener distintos parametros y faltar funcionalidad.
 * 
 * Código modificado, de CPP an C
 * Compilar: gcc -oej6 ej6-hist.c -g -ggdb `pkg-config --cflags --libs opencv` -Wall
 */

#include <cv.h>
#include <highgui.h>
#include <stdio.h>

int main( int argc, char** argv )
{
  IplImage *src, *hsv;

  char* source_window = "Source image";
  char* equalized_window = "Equalized Image";

  /// Load image
  src = cvLoadImage("./lenna.jpeg",0);

  /// http://docs.opencv.org/modules/imgproc/doc/histograms.html#calchist
  cvCalcHist( &src, hsv, channels, 0, NULL);

  int scale = 10;
  Mat histImg = Mat::zeros(sbins*scale, hbins*10, CV_8UC3);

  for( int h = 0; h < hbins; h++ )
      for( int s = 0; s < sbins; s++ )
      {
          float binVal = hist.at<float>(h, s);
          int intensity = cvRound(binVal*255/maxVal);
          cvRectangle( histImg, Point(h*scale, s*scale),
                      Point( (h+1)*scale - 1, (s+1)*scale - 1),
                      Scalar::all(intensity),
                      CV_FILLED );
      }

  namedWindow( "Source", 1 );
  imshow( "Source", src );

  namedWindow( "H-S Histogram", 1 );
  imshow( "H-S Histogram", histImg );
  waitKey();
}

















  /// Convert to grayscale
  cvtColor( src, src, CV_BGR2GRAY );

  /// Apply Histogram Equalization
  equalizeHist( src, dst );

  /// Display results
  namedWindow( source_window, CV_WINDOW_AUTOSIZE );
  namedWindow( equalized_window, CV_WINDOW_AUTOSIZE );

  imshow( source_window, src );
  imshow( equalized_window, dst );

  /// Wait until user exits the program
  waitKey(0);

  return 0;
}
