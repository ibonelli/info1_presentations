/**
 * \file imgproc
 * \brief Programa sencillo para abrir una imagen y presentarla en una ventana
 * \details Utilizamos la biblioteca Opencv para abrir la imagen aprovechando 
 * sus funciones independientes del tipo de archivo, y también para crear una
 * ventana sencilla (sin menú), para presentarla en la GUI del sistema operativo
 * que se tenga (Linux, Windows, o MAC OS).
 * Este programa compila en Linux, mediante el comando siguiente:
 * gcc -o img img.c `pkg-config --cflags --libs opencv` -g -ggdb -Wall 
 * \author Alejandro Furfaro. afurfaro@electron.frba.utn.edu.ar
 * \date 12.05.2011
*/ 

#include <cv.h>
#include <highgui.h>
#include <stdio.h>

int main()
{
  char c;
  //Instancia una estructura IplImage, definida en openCV para 
  //cargar la información de la imagen origen
  IplImage* Imagen;
  
  CvCapture* captura = cvCreateCameraCapture(0);
  
  cvNamedWindow("Ejemplo 1", CV_WINDOW_AUTOSIZE);
  
  while(1)
  {
    Imagen = cvQueryFrame(captura);
    if(!Imagen) break;
    cvShowImage("Ejemplo 1", Imagen);
    c = cvWaitKey(33);
    if(c==27) break;
  }
  cvReleaseCapture(&captura);
  cvDestroyWindow("Ejemplo 1");
  return 0;
}

