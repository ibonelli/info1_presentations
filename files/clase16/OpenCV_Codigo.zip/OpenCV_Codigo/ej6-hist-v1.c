/*
 * De: http://docs.opencv.org/doc/tutorials/imgproc/histograms/histogram_equalization/histogram_equalization.html
 * Código modificado, de CPP an C
 * Compilar: gcc -oej6 ej6-hist.c -g -ggdb `pkg-config --cflags --libs opencv` -Wall
 */

#include <cv.h>
#include <opencv2/imgproc/imgproc_c.h>
#include <highgui.h>
#include <stdio.h>

/**  @function main */
int main( int argc, char** argv )
{
  IplImage *src, *dst;

  char* source_window = "Source image";
  char* equalized_window = "Equalized Image";

  /// Load image
  src = cvLoadImage("./lenna.jpeg",0);

  /// Convert to grayscale
  cvtColor( src, src, CV_BGR2GRAY );

  /// Apply Histogram Equalization
  equalizeHist( src, dst );

  /// Display results
  namedWindow( source_window, CV_WINDOW_AUTOSIZE );
  namedWindow( equalized_window, CV_WINDOW_AUTOSIZE );

  imshow( source_window, src );
  imshow( equalized_window, dst );

  /// Wait until user exits the program
  waitKey(0);

  return 0;
}
