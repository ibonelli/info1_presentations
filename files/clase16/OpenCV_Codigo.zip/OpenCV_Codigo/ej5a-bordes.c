#include "ej5-imgproc.h"

/**
 * \fn void procesar_imagen(unsigned char * ImgOriginal, unsigned char * ImgResultado, int ancho, int alto)
 * \brief Recibe un puntero a imagen y devuelve un puntero a su imagen solo bordes
 * \details Procesa el mapa de bits de una imagen monocromática, y genera 
 * una imagen con solamente los bordes de la original.
 * Emplea el método de la derivada en cada pixel, esto es la diferencia entre
 * dos valores consecutivos sobre el intervalo entre ambos cuando este tiende 
 * a cero. La mejor aproximación de un intervalo inter pixeles que tiende a cero
 * es un pixel, ya que el la mínima unidad en el eje consideardo de la variable
 * independiente. Por tal motivo, restando a cada pixel el valor de su vecino, 
 * se tiene la derivada.
 * De este modo para obtener la derivada en ambos ejes de un plano (las imágenes 
 * planas tienen dos dimensiones y por ende dos variables independientes, la 
 * expresión de nuestro algoritmo será:
 * 		D = 2*Pnm - P(n+1)m - Pn(m+1)
 * Donde D es la derivada, Pnm es el pixel de coordenadas (n,m) (fila columna), 
 * P(n+1)m el pixel de abajo del considerado, y Pn(m+1), el de al lado.
 * Si los valores de intensidad de ambos vecinos son semejantes D es muy próxima 
 * a 0, y no constituye un borde. Si uno de los dos pixeles vecinos difiere en 
 * intensidad fuertemente respecto del pixel considerado, existe un borde, y D 
 * será cercano a 255 (máximo valor de intensidad)
 * El cálculo se hace pixel a pixel barriendo la imagen desde izquierda a
 * derecha y desde arriba hacia abajo.
 * \param [in] ImgOriginal. Puntero a char con el mapa de bits de la imagen a 
 * procesar.
 * \param [in] ImgResultado. Puntero a char con la imagen a devolver procesada
 * \param [in] ancho. Dimensión horizontal en píxeles de la imagen.
 * \param [in] alto. Dimensión vertical en píxeles de la imagen.
 * \return Nada
 * \author Alejandro Furfaro
 * \date 15.10.2010
 */


void	procesar_imagen(unsigned char * ImgOriginal, unsigned char * ImgResultado, int ancho, int alto)
{
	int	fila,col;
	int nivelBorde = 2;

	for (fila =0; fila < (alto -1) ; fila++)
		for (col=0; col < (ancho -1); col++, ImgResultado++, ImgOriginal++)
			*ImgResultado = nivelBorde * (unsigned char) abs ((int)
				2*(*ImgOriginal) - (int) *(ImgOriginal+ancho) -
				(int) *(ImgOriginal+1));

	return;
}
