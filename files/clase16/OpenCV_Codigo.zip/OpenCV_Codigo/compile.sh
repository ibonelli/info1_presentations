gcc -oej1a ej1a-jpg.c -g -ggdb -lm `pkg-config --cflags --libs opencv` -Wall
gcc -oej1b ej1b-bmp.c -g -ggdb -lm `pkg-config --cflags --libs opencv` -Wall
gcc -oej2 ej2-webcam.c -g -ggdb -lm `pkg-config --cflags --libs opencv` -Wall
gcc -oej3a ej3a-invert.c -g -ggdb -lm `pkg-config --cflags --libs opencv` -Wall
gcc -oej3b ej3b-invert.c -g -ggdb -lm `pkg-config --cflags --libs opencv` -Wall
gcc -oej4a ej4a-canny.c -g -ggdb -lm `pkg-config --cflags --libs opencv` -Wall
gcc -oej4b ej4b-canny.c -g -ggdb -lm `pkg-config --cflags --libs opencv` -Wall
gcc -oej5a ej5-imgproc.c ej5a-bordes.c -g -ggdb -lm `pkg-config --cflags --libs opencv` -Wall
gcc -oej5b ej5-imgproc.c ej5b-resize.c -g -ggdb -lm `pkg-config --cflags --libs opencv` -Wall
gcc -oej5c ej5-imgproc.c ej5c1-blur.c -g -ggdb -lm `pkg-config --cflags --libs opencv` -Wall
gcc -oej5d ej5-imgproc.c ej5c2-blur2.c -g -ggdb -lm `pkg-config --cflags --libs opencv` -Wall
