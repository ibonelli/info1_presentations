#include <cv.h>
#include <highgui.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

/* Prototipo de la funci�n para detecci�n de bordes:
 * Recibe un puntero a char que es el buffer de la imagen origen, 
 * y otro puntero a char a la imagen destino, un entero con la 
 * cantidad de pixeles de alto de la imagen y otro entero con la 
 * cantidad de pixeles de una fila.
 */

void	procesar_imagen(unsigned char *, unsigned char*, int, int);
