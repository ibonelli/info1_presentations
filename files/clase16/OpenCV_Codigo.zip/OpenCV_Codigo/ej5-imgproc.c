/**
 * \file imgproc
 * \brief Programa sencillo para abrir una imagen y presentarla en una ventana
 * \details Utilizamos la biblioteca Opencv para abrir la imagen aprovechando 
 * sus funciones independientes del tipo de archivo, y tambi�n para crear una
 * ventana sencilla (sin men�), para presentarla en la GUI del sistema operativo
 * que se tenga (Linux, Windows, o MAC OS).
 * Adem�s presentar� en una segunda ventana el resultado de la detecci�n de 
 * bordes de la imagen. 
 * Este programa compila en Linux, mediante el comando siguiente:
 * gcc -o ej3 ej3-imgproc.c ej3-bordes.c `pkg-config --cflags --libs opencv` -g -ggdb -Wall 
 * \author Alejandro Furfaro. afurfaro@electron.frba.utn.edu.ar
 * \date 12.05.2011
*/ 

#include "ej5-imgproc.h"


int	main (int argc, char * argv [])
{
	//Instancia dos estructuras IplImage, definidas en openCV para 
	//cargar la informaci�n de la imagen origen y para guardar el 
	//resultadodel procesamiento de bordes
	IplImage* src = 0;
	IplImage* dst = 0;

	//Si se pas� como argumento, tomamos este como nombre de archivo,
	// sino el default LENA.BMP
	//char* filename = argc == 2 ? argv[1] : (char*) "gato.bmp";
	char* filename = argc == 2 ? argv[1] : (char*) "lenna.jpeg";

	//Carga imagen con librer�a openCV
	if( (src = cvLoadImage(filename,0)) == 0 )
		return -1;

	//Presentamos par�metros de la imagen de la estructura IPlImage
	//resultante del archivo de trabajo
	printf ("Imagen %s:\n%d pixeles de ancho por %d pixeles de alto. Tama�o: %d, Fila[bytes]: %d\n", filename, src->width, src->height, src->imageSize, src->widthStep);

	//Creamos una imagen del mismo tama�o y caracter�sticas de 
	//la original
	dst = cvCreateImage(cvSize(src->width,src->height), src->depth, src->nChannels);

	//creamos ventana para la imagen original
	cvNamedWindow("Imagen original",CV_WINDOW_AUTOSIZE);
	// Presentamos la imagen original para tener como referencia
	cvShowImage("Imagen original",src);


	//Llamamos a la funci�n de detecci�n de bordes
	procesar_imagen((unsigned char *) src->imageData, (unsigned char *) dst->imageData, src->widthStep, src->height);

	//creamos ventana para la detecci�n de bordes
	cvNamedWindow("Bordes",CV_WINDOW_AUTOSIZE);
	//La movemos al lado de la original
	cvMoveWindow("Bordes",src->width,0);
	// Presentamos el resultado
	cvShowImage("Bordes",dst);

	cvWaitKey(0);

	//Liberamos imagenes
	cvReleaseImage(&src);
	cvReleaseImage(&dst);

	//destruimos las ventanas windows 
	cvDestroyWindow("Imagen original"); 
	cvDestroyWindow("Bordes"); 
	return 0;
}

