/*
 * De: http://docs.opencv.org/doc/tutorials/imgproc/histograms/histogram_equalization/histogram_equalization.html
 * Y: http://docs.opencv.org/modules/imgproc/doc/histograms.html#calchist
 * 
 * Sigo sin lograr pasarlo a C...
 * 
 * Compilar: gcc -oej6 ej6-hist-v3.c -g -ggdb `pkg-config --cflags --libs opencv` -Wall
 */

// 

#include <cv.h>
#include <highgui.h>
#include <stdio.h>


int main()
{
	IplImage *imgOrig;
	CvHistogram *hist = NULL;

	int hist_size[2];
	float h_ranges[] = { 0, 180 };
	float s_ranges[] = { 0, 255 };
	float* ranges[] = { h_ranges, s_ranges };

	cvNamedWindow("Original",CV_WINDOW_AUTOSIZE);
	cvNamedWindow("Histograma",CV_WINDOW_AUTOSIZE);

	imgOrig = cvLoadImage("lenna.jpeg",0); // La leo en escala de grises por que el cvCanny solo funciona con imagenes en escala de Grices
	cvShowImage("Original",imgOrig);

	hist_size[0] = imgOrig->width; hist_size[1] = imgOrig->height;
	hist = cvCreateHist(2, hist_size, CV_HIST_ARRAY, ranges, 1);

    cvCalcHist(&imgOrig, hist, 0, NULL);

	// wait for a key
	cvWaitKey(0);
	// Esta version de cierre no funciona
	// while( cvWaitKey(100) != 27); //Sale con esc

	// release the image
	cvReleaseImage(&imgOrig);
	cvDestroyWindow("Original");
	cvDestroyWindow("Histograma");

	return 0;
}

