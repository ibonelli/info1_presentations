// cany.cpp: define el punto de entrada de la aplicaci�n de consola.
// Similar a: http://opencv.wikispaces.com/4%29+Inverting+the+Image
// Compilar: gcc -oej4 ej4-canny.c -g -ggdb `pkg-config --cflags --libs opencv` -Wall

#include <cv.h>
#include <highgui.h>
#include <stdio.h>


int main()
{
	IplImage *imgOrig;
	IplImage *imgBordes;
	cvNamedWindow("Original",CV_WINDOW_AUTOSIZE);
	cvNamedWindow("Bordes",CV_WINDOW_AUTOSIZE);
	imgOrig = cvLoadImage("lenna.jpeg",0); // La leo en escala de grises por que el cvCanny solo funciona con imagenes en escala de Grices

	imgBordes =  cvCreateImage( cvGetSize(imgOrig), IPL_DEPTH_8U, 1 );

	cvCanny( imgOrig, imgBordes, 15, 100, 3); 
	cvShowImage("Original",imgOrig);
	cvShowImage("Bordes",imgBordes);

	// wait for a key
	cvWaitKey(0);
	// Esta version de cierre no funciona
	// while( cvWaitKey(100) != 27); //Sale con esc

	// release the image
	cvReleaseImage(&imgOrig);
	cvReleaseImage(&imgBordes);
	cvDestroyWindow("Original");
	cvDestroyWindow("Bordes");

	return 0;
}

