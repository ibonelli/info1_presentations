/**
	\file main.h
	\brief Archivo include del main.
	\author Ing. Jerónimo F. Atencio (jerome5416@gmail.com)
	\date 2010.06.05
	\version 1.0.0
*/
#ifndef MAIN_H
#define MAIN_H



#endif
