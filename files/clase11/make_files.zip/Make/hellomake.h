/* Example include file */

void myPrintHelloMake(void);
