#include <allegro5/allegro.h>
#include <allegro5/allegro_image.h>
#include <allegro5/allegro_font.h>
#include <allegro5/allegro_ttf.h>

int width = 640;
int height = 480;

struct Sprite
{
	float x;
	float y;
	float velX;
	float velY;
	int dirX;
	int dirY;

	int maxFrame;
	int curFrame;
	int frameCount;
	int frameDelay;
	int frameWidth;
	int frameHeight;
	int animationColumns;
	int animationDirection;

	ALLEGRO_BITMAP *image;
};

void InitSprites(Sprite &sprite, ALLEGRO_BITMAP *image);
void UpdateSprites(Sprite &sprite);
void DrawSprites(Sprite &sprite);

int main(void)
{
	//variables
	bool done = false;
	bool render = false;	
	float gameTime = 0;
	int frames = 0;
	int gameFPS = 0;

	const int numSprites = 150;

	Sprite orbs[numSprites];

	//allegro variable
	ALLEGRO_DISPLAY *display = NULL;
	ALLEGRO_EVENT_QUEUE *event_queue = NULL;
	ALLEGRO_FONT *font18 = NULL;
	ALLEGRO_TIMER *timer;
	ALLEGRO_BITMAP *image;
	
	//program init
	if(!al_init())										//initialize Allegro
		return -1;

	display = al_create_display(width, height);			//create our display object

	if(!display)										//test display object
		return -1;

	//addon init
	al_install_keyboard();
	al_init_image_addon();
	al_init_font_addon();
	al_init_ttf_addon();

	font18 = al_load_font("arial.ttf", 18, 0);

	image = al_load_bitmap("space-core.png");
	al_convert_mask_to_alpha(image, al_map_rgb(106, 76, 48));

	for(int i = 0; i < numSprites; i++)
		InitSprites(orbs[i], image);

	
	event_queue = al_create_event_queue();
	timer = al_create_timer(1.0 / 60);

	al_register_event_source(event_queue, al_get_timer_event_source(timer));
	al_register_event_source(event_queue, al_get_keyboard_event_source());

	al_start_timer(timer);
	gameTime = al_current_time();

	while(!done)
	{
		ALLEGRO_EVENT ev;
		al_wait_for_event(event_queue, &ev);

		if(ev.type == ALLEGRO_EVENT_KEY_DOWN)
		{
			switch(ev.keyboard.keycode)
			{
			case ALLEGRO_KEY_ESCAPE:
				done = true;
				break;
			case ALLEGRO_KEY_LEFT:
				
				break;
			case ALLEGRO_KEY_RIGHT:
				
				break;
			case ALLEGRO_KEY_UP:
				
				break;
			case ALLEGRO_KEY_DOWN:
				
				break;
			}
		}
		else if(ev.type == ALLEGRO_EVENT_TIMER)
		{
			frames++;
			if(al_current_time() - gameTime >= 1)
			{
				gameTime = al_current_time();
				gameFPS = frames;
				frames = 0;
			}

			for(int i = 0; i < numSprites; i++)
				UpdateSprites(orbs[i]);

			render = true;
		}

		if(render && al_is_event_queue_empty(event_queue))
		{
			render = false;
						
			for(int i = 0; i < numSprites; i++)
				DrawSprites(orbs[i]);

			al_draw_textf(font18, al_map_rgb(255, 0, 255), 5, 5, 0, "FPS: %i", gameFPS);

			al_flip_display();
			al_clear_to_color(al_map_rgb(0,0,0));
		}
	}

	al_destroy_bitmap(image);
	al_destroy_font(font18);
	al_destroy_event_queue(event_queue);
	al_destroy_display(display);						//destroy our display object

	return 0;
}

void InitSprites(Sprite &sprite, ALLEGRO_BITMAP *image)
{
	sprite.x = rand() % (width - 20) + 20;
	sprite.y = rand() % (height - 20) + 20;
	sprite.velX = rand() % 7 + 2;
	sprite.velY = rand() % 7 + 2;
	sprite.dirX = -1;
	sprite.dirY = -1;

	sprite.maxFrame = 71;
	sprite.curFrame = 0;
	sprite.frameCount = 0;
	sprite.frameDelay = 5;
	sprite.frameWidth = 64;
	sprite.frameHeight = 64;
	sprite.animationColumns = 16;
	sprite.animationDirection = 1;

	sprite.image = image;
}

void UpdateSprites(Sprite &sprite)
{
	if(++sprite.frameCount >= sprite.frameDelay)
	{
		sprite.curFrame += sprite.animationDirection;
		if(sprite.curFrame >= sprite.maxFrame)
			sprite.curFrame = 0;
		else if(sprite.curFrame <= 0)
			sprite.curFrame = sprite.maxFrame - 1;

		sprite.frameCount = 0;
	}

	sprite.x += sprite.velX * sprite.dirX;
	sprite.y += sprite.velX * sprite.dirY;

	if((sprite.x <= 0 && sprite.dirX == -1) || 
		(sprite.x >= width - sprite.frameWidth && sprite.dirX == 1))
	{
		sprite.dirX *= -1;
		sprite.animationDirection *= -1;
	}
	if((sprite.y <= 0 && sprite.dirY == -1) ||
		(sprite.y >= height - sprite.frameHeight && sprite.dirY == 1))
	{
		sprite.dirY *= -1;
		sprite.animationDirection *= -1;
	}
}


void DrawSprites(Sprite &sprite)
{
	int fx = (sprite.curFrame % sprite.animationColumns) * sprite.frameWidth;
	int fy = (sprite.curFrame / sprite.animationColumns) * sprite.frameHeight;

	al_draw_bitmap_region(sprite.image, fx, fy, sprite.frameWidth,
		sprite.frameHeight, sprite.x, sprite.y, 0);
}