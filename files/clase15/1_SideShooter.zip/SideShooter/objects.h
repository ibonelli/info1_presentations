//Object IDS
enum IDS{PLAYER, BULLET, ENEMY};

//Our Player
struct SS
{
	int ID;
	int x;
	int y;
	int lives;
	int speed;
	int boundx;
	int boundy;
	int score;
};
typedef struct SS SpaceShip;

struct B
{
	int ID;
	int x;
	int y;
	bool live;
	int speed;
};
typedef struct B Bullet;

struct C
{
	int ID;
	int x;
	int y;
	bool live;
	int speed;
	int boundx;
	int boundy;
};
typedef struct C Comet;
