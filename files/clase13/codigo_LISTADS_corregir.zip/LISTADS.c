#include <stdio.h>
#include <stdlib.h>

struct lid	{	int n;
	struct lid *sig;
	struct lid *ant;};

void ingresa(struct lid **);
void lee(struct lid **);
void borra(struct lid **);
void busca(struct lid **);

void main(void)
	{
		int op;
		struct lid *pr=NULL;
		for(;;)
			{
				system("clear");
				printf("1 - Ingresa datos\n");
				printf("2 - Lee datos\n");
				printf("3 - Borrar datos\n");
				printf("4 - Buscar datos\n");
				printf("5 - Salir\n\n");
				printf("Ingrese una opcion ( 1 - 5 ) : ");
				op=getchar();
				switch(op)
					{
							case	'1':	ingresa(&pr);
													break;
							case  '2':	lee(&pr);
													break;
							case  '3': 	borra(&pr);
													break;
							case  '4': 	busca(&pr);
													break;
							case  '5': 	exit(0);
					}
			}
	}
void ingresa(struct lid **p)
	{
		struct lid *act,*aux,*ant;
		if(!(aux=(struct lid *)malloc(sizeof(struct lid))))
				{
					printf("\n\nNo hay memoria disponible\n");
					printf("\n\nPresione una tecla para continuar\n");
					getchar();
					return;
				}
		printf("\n\nIngrese los datos : ");
		scanf("%d",&aux->n);
		if(!*p)
				{
					*p=aux;
					aux->sig=NULL;
					aux->ant=NULL;
					return;
				}
		ant=*p;
		act=*p;
		while((act->n<aux->n)&&act)
			{
				ant=act;
				act=act->sig;
			}
		if(!act)
				{
					ant->sig=aux;
					aux->sig=NULL;
					aux->ant=ant;
					return;
				}
		if(ant==act)
				{
					*p=aux;
					aux->sig=ant;
					aux->ant=NULL;
					ant->ant=aux;
					return;
				}
		ant->sig=aux;
		aux->sig=act;
		aux->ant=ant;
		act->ant=aux;
	}
void lee(struct lid **p)
	{
		struct lid *aux=*p;
		while(aux)
			{
				printf("\nEl dato es : %d\n\n",aux->n);
				aux=aux->sig;
				printf("\nPresione una tecla para continuar\n");
				getchar();
			}
	}
void borra(struct lid **p)
	{
		struct lid *aux,*ant;
		int b;
		char k;
		printf("\nIngrese el nro de socio a borrar : ");
		scanf("%d",&b);
		aux=*p;
		ant=*p;
		while((b!=aux->n)&&aux)
			{
				ant=aux;
				aux=aux->sig;
			}
		if(aux)
				{
					printf("\nEl dato es : %d\n\n",aux->n);
					printf("\n\nDesea eliminar estos datos (S / N) ");
					k=toupper(getchar());
					if(k=='S')
							{
								if(ant==aux)
										{
											*p=aux->sig;
											aux->sig->ant=NULL;
											free(aux);
											return;
										}
								ant->sig=aux->sig;
								ant->sig->ant=ant;
								free(aux);
								return;
							}
					return;
				}
		printf("\nEl dato no ha sido encontrado");
		printf("\n\nPresione una tecla para continuar\n");
		getchar();
	}
void busca(struct lid **p)
	{
		struct lid *aux;
		int b;
		char k;
		printf("\nIngrese el dato a buscar : ");
		scanf("%d",&b);
		aux=*p;
		while((b!=aux->n)&&aux)
			aux=aux->sig;
		if(aux)
				{
					printf("\nEl dato es : %d\n\n",aux->n);
					printf("\n\nPresione una tecla para continuar\n");
					getchar();
					return;
				}
		printf("\nEl dato no ha sido encontrado");
		printf("\n\nPresione una tecla para continuar\n");
		getchar();
	}
