 /**
	\file lseTurboMain.c
	\brief Ejemplo de uso de las funciones de la unidad lseTurbo.c
	\author Ing. Jerónimo F. Atencio (jerome5416@gmail.com)
	\date 2010.05.02
	\version 1.0.0
*/ 
 
//--------------
//-- Includes --
//--------------
#include <stdlib.h>
#include <stdio.h>
#include "lseTurbo.h"

/**
	\fn void imprimir (void *dataPtr)
	\brief Funcion para imprimir los datos de los nodos.
	\author Ing. Jerónimo F. Atencio (jerome5416@gmail.com)
	\date 2013.05.02
	\return Retorna 0
*/
void imprimir (void *dataPtr) {
int *auxPtr;
	//-- Casteo el puntero --
	auxPtr = (int*)dataPtr;
	//-- Imprimo los datos --
	printf ("%d\r\n", *auxPtr);
}

/**
	\fn int comparar (void *aParam, void *bParam) 
	\brief Funcion de comparacion para la busqueda o eliminación de nodos.
	\author Ing. Jerónimo F. Atencio (jerome5416@gmail.com)
	\date 2013.05.02
	\return Retorna 0
*/
int comparar (void *aParam, void *bParam) {
int *a, *b;

	a = (int *)aParam;
	b = (int *)bParam;
	
	return (*a == *b);
}

/**
	\fn int main (void)
	\brief Prueba de lseTurbo. En este ejemplo se almacenan solamente enteros.
	\author Ing. Jerónimo F. Atencio (jerome5416@gmail.com)
	\date 2013.05.02
	\return Retorna 0
*/
int main (void) 
{
int data[] = {1, 2, 3, 4, 10, 11, 12, 13};	//-- Datos a insertar en la lista --
struct nodoTurbo_S *h = NULL;				//-- Puntero a la cabeza de la lista --
struct nodoTurbo_S *aux;					//-- Puntero auxiliar --
int i;
	
	printf ("sizeof (struct nodoTurbo_S) = %ld\r\nsizeof (struct nodoTurbo_S*) = %ld\r\n\r\n", sizeof (struct nodoTurbo_S),  sizeof (struct nodoTurbo_S*));
		
	//-- Inserto en la lista --
	for (i = 0; i < 4; i++) {
		lseTurboInsertarInicio (&h, &data[i], sizeof (data));
	}
	
	//-- Imprimo los datos --
	puts ("\r\nImprimo los datos:");
	lseTurboImprimir (&h, imprimir);
	

	//-- Cuenta la cantidad de nodos --
	printf ("Nodos cant: %d\r\n", lseTurboContar (&h));
	
	//-- Inserto en la lista --
	for (i = 4; i < 8; i++) {
		lseTurboInsertarFinal (&h, &data[i], sizeof (data));
		
	}
		
	//-- Imprimo los datos --
	puts ("\r\nImprimo los datos:");
	lseTurboImprimir (&h, imprimir);

	//-- Cuenta la cantidad de nodos --
	printf ("Nodos cant: %d\r\n", lseTurboContar (&h));

	//-- Busco algo que esta en la lista --
	puts ("\r\nBusco en la lista el número 12:");
	i = 12;
	aux = lseTurboBuscar (&h, &i, comparar);
	if (aux != NULL) {
		printf ("Lo encontré\r\n");
	} else {
		printf ("No lo encontré\r\n");
	}
	
	//-- Busco algo que no esta en la lista --
	puts ("\r\nBusco en la lista el número 24:");
	i = 24;
	aux = lseTurboBuscar (&h, &i, comparar);
	if (aux != NULL) {
		printf ("Lo encontré\r\n");
	} else {
		printf ("No lo encontré\r\n");
	}

	//-- remuevo un nodo de la lista --
	puts ("\r\nRemuevo un nodo de la lista que tenga el numero 12 como dato:");
	i = 12;
	lseTurboRemover (&h, &i, comparar);
	lseTurboImprimir (&h, imprimir);
	
	//-- Liberar los datos --
	puts ("\r\nLibero la memoria pedida");
	lseTurboLiberar (&h);
	
	//-- Cuenta la cantidad de nodos --
	printf ("Nodos cant: %d\r\n\r\n", lseTurboContar (&h));

	return (0);
} 
