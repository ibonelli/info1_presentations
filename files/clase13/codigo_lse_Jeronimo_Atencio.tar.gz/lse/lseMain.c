 /**
	\file lseMain.c
	\brief Ejemplo de uso de las funciones de la unidad lse.c
	\author Ing. Jerónimo F. Atencio (jerome5416@gmail.com)
	\date 2010.05.02
	\version 1.0.0
	\todo Agregar funcion para insertar ordenado
*/ 
 
//--------------
//-- Includes --
//--------------
#include <stdlib.h>
#include <stdio.h>
#include "lse.h"

/**
	\fn int main (void)
	\brief Prueba de lse
	\author Ing. Jerónimo F. Atencio (jerome5416@gmail.com)
	\date 2013.05.02
	\return Retorna siempre 0
*/
int main (void) 
{
int data[] = {1, 2, 3, 4};	//-- Datos a insertar en la lista --
struct nodo_S *h = NULL;	//-- Puntero a la cabeza de la lista --
struct nodo_S *aux;			//-- Puntero auxiliar --
int i;
	
	//-- Imprimo los size of para poder entender las direcciones impresas --
	printf ("sizeof (struct nodo_S) = %ld\r\nsizeof (struct nodo_S*) = %ld\r\n\r\n", sizeof (struct nodo_S),  sizeof (struct nodo_S*));

	//-- Inserto en la lista --
	for (i = 0; i < 4; i++) {
		lseInsertarInicio (&h, data[i]);
	}
	//-- Imprimo los datos --
	lseImprimir (&h);

	//-- Cuenta la cantidad de nodos --
	printf ("Nodos cant: %d\r\n", lseContar (&h));
	
	//-- Inserto en la lista --
	for (i = 0; i < 4; i++) {
		lseInsertarFinal (&h, data[i] + 10);
	}
		
	//-- Imprimo los datos --
	lseImprimir (&h);

	//-- Cuenta la cantidad de nodos --
	printf ("Nodos cant: %d\r\n", lseContar (&h));
		
	//-- Busco algo que esta en la lista --
	puts ("\r\nBusco en la lista el número 12:");
	aux = lseBuscar (&h, 12);
	if (aux != NULL) {
		printf ("Lo encontré\r\n");
	} else {
		printf ("No lo encontré\r\n");
	}
	
	//-- Busco algo que no esta en la lista --
	puts ("\r\nBusco en la lista el número 24:");
	aux = lseBuscar (&h, 25);
	if (aux != NULL) {
		printf ("Lo encontré\r\n");
	} else {
		printf ("No lo encontré\r\n");
	}
	
	//-- Remuevo un nodo de la lista --
	puts ("\r\nRemuevo un nodo de la lista que tenga el numero 3 como dato:");
	lseRemover (&h, 3);
	lseImprimir (&h);
	
	//-- Liberar los datos --
	puts ("\r\nLibero la memoria pedida");
	lseLiberar (&h);
	
	//-- Cuenta la cantidad de nodos --
	printf ("Nodos cant: %d\r\n", lseContar (&h));

	return (0);
} 
