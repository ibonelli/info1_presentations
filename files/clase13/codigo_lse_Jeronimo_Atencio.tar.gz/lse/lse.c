/**
	\file lse.c
	\brief API de listas simple enlazadas. 
	\details Los datos que almacena esta lista son numeros enteros, ver la estructura nodo_S en lse.h
	\author Ing. Jerónimo F. Atencio (jerome5416@gmail.com)
	\date 2010.05.02
	\version 1.0.0
*/
//--------------
//-- Includes --
//--------------
#include <stdlib.h>
#include <stdio.h>
#include "lse.h"
/**
	\fn int lseInsertarInicio (struct nodo_S **h, int data)
	\brief Inserta un nuevo nodo a la lista siemple enlazada, esta funcionando como una pila.
	\author Ing. Jerónimo F. Atencio (jerome5416@gmail.com)
	\date 2013.02.02
	\param **h Puntero al puntero de la cabeza de la lista.
	\param data Dato a insertar en la lista.
	\return Retorna -1 en caso de error y setea errno, devuelve cero en caso contrario.
*/
int lseInsertarInicio (struct nodo_S **h, int data) {
struct nodo_S *p;
	
	//-- Pido memoria --
	p = (struct nodo_S*)malloc (sizeof (struct nodo_S));
	if (p == NULL) {
		//-- No hay memoria --
		return (-1);
	} else {
		//-- Relleno la estructura --
		p->data = data;
		//-- Pongo el nodo al principio --
		p->sig = *h;		//-- Si es el primer nodo de la lista *h es NULL --
		*h = p;				//-- Apunto el puntero a la cabeza de la lista al  nuevo nodo --
		return (0);
	}
}

/**
	\fn void lseImprimir (struct nodo_S **h)
	\brief Imprime los datos de la lista.
	\author Ing. Jerónimo F. Atencio (jerome5416@gmail.com)
	\date 2013.05.02
	\param **h Puntero al puntero de la cabeza de la lista.
	\return void
*/
void lseImprimir (struct nodo_S **h) {
struct nodo_S *p;
int i = 0;
	//-- Voy recorriendo la lista e imprimiendo nodos --
	puts ("");
	printf("Index\tData\t\tDirNodo\t\tDirNodoSig\r\n");
	for (p = *h; p != NULL; p = p->sig) {
		printf("%02d\t%08d\t%p\t%p\r\n", i++, p->data, p, p->sig);
	}
	puts ("");
}

/**
	\fn void lseLiberar (struct nodo_S **h)
	\brief Libera toda la lista.
	\author Ing. Jerónimo F. Atencio (jerome5416@gmail.com)
	\date 2013.05.02
	\param **h Puntero al puntero de la cabeza de la lista.
	\return void
*/
void lseLiberar (struct nodo_S **h) {
struct nodo_S *p, *aux;

	if (*h == NULL) {
		//-- Lista vacia --		
		return;
	} else {
		//-- Voy recorriendo la lista y eliminando nodos --	
		for (p = *h; p != NULL;) {
			//** Debug **
			//printf ("%p\r\n", p);
			//** Debug **
			aux = p;	//-- Salvo el puntero al nodo a eliminar --
			p = p->sig;	//-- Me muevo al siguiente nodo --
			free (aux);	//-- libero el nodo actual --
		}
		*h = p;	//-- Pongo el puntero a la cabeza de la lista en NULL --
	}
}

/**
	\fn int lseContar (struct nodo_S **h)
	\brief Cuenta la cantidad de nodos de la lista.
	\author Ing. Jerónimo F. Atencio (jerome5416@gmail.com)
	\date 2013.02.02
	\param **h Puntero al puntero de la cabeza de la lista.
	\return Cantidad de nodos de la lista
	
*/
int lseContar (struct nodo_S **h) {
struct nodo_S *p;
int i;

	for (p = *h, i = 0; p != NULL; p = p->sig, i++);
	return (i);
}

/**
	\fn int lseInsertarFinal (struct nodo_S **h, int data)
	\brief Inserta un nuevo nodo a la lista siemple enlazada, esta funcionando como una pila.
	\author Ing. Jerónimo F. Atencio (jerome5416@gmail.com)
	\date 2013.02.02
	\param **h Puntero al puntero de la cabeza de la lista.
	\param data Dato a insertar en la lista.
	\return Retorna -1 en caso de error y setea errno, devuelve cero en caso contrario.
*/
int lseInsertarFinal (struct nodo_S **h, int data) {
struct nodo_S *p, *aux;
	
	//-- Pido memoria --
	p = (struct nodo_S*)malloc (sizeof (struct nodo_S));
	if (p == NULL) {
		//-- No hay memoria --
		return (-1);
	} else {
		//-- Relleno la estructura --		
		p->data = data;
		p->sig = NULL;		//-- Como es el ultimo nodo apunto el sig a NULL --
		
		//-- Me fijo donde insertarlo --
		if (*h == NULL) {
			//-- La lista esta vacia --
			*h = p;
		} else {
			//-- Busco el último nodo --
			for (aux = *h; aux->sig != NULL; aux = aux->sig);
			//-- Inserto el nodo al final --
			aux->sig = p;
		}
		return (0);
	}
}

/**
	\fn struct nodo_s* lseBuscar (struct nodo_S **h, int data)
	\brief Cuenta la cantidad de nodos de la lista.
	\author Ing. Jerónimo F. Atencio (jerome5416@gmail.com)
	\date 2013.02.02
	\param **h Puntero al puntero de la cabeza de la lista.
	\param data Dato a buscar.
	\return Un puntero al elemento encontrado, NULL en caso contrario.
	
*/
struct nodo_S* lseBuscar (struct nodo_S **h, int data) {
struct nodo_S *p;

	//-- Recorro la lista --
	for (p = *h; p != NULL; p = p->sig) {
		if (p->data == data) {
			//-- Encontre el dato --
			return (p);
		}
	}
	//-- Si sali del for es que no encontre nada --
	return (NULL);
}

/**
	\fn int lseRemover (struct nodo_S **h, int data)
	\brief Remueve un nodo de la lista. 
	\details Si hay dos nodos con el mismo datos, remueve solo el primero que encuentra.
	\author Ing. Jerónimo F. Atencio (jerome5416@gmail.com)
	\date 2013.02.02
	\param **h Puntero al puntero de la cabeza de la lista.
	\param data Dato a remover.
	\return Retorna 1 si encontro y removio el nodo en la lista, 0 en caso contrario
	
*/
int lseRemover (struct nodo_S **h, int data) {
struct nodo_S *p, *aux;

	//-- Me fijo si hay algo en la lista --
	if (*h != NULL) {
		//-- Busco el nodo a eliminar --
		for (p = *h, aux = NULL; p != NULL; aux = p, p = p->sig){
			if (p->data == data) {
				//-- Encontre el dato --
				if (aux == NULL) {
					//-- Es el primer nodo --
					*h = p->sig;
				} else {
					aux->sig = p->sig;
				}
				free (p);
				return (1);
			}
		}
	} else {
		//-- Lista vacia --
		return (0);
	}
	return (0);
}

