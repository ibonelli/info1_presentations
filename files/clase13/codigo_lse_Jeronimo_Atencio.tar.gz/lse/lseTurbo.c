/**
	\file lseTurbo.c
	\brief API de listas simple enlazadas
	\author Ing. Jerónimo F. Atencio (jerome5416@gmail.com)
	\date 2010.05.02
	\version 1.0.0
*/
//--------------
//-- Includes --
//--------------
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "lseTurbo.h"

/**
	\fn int lseTurboInsertarInicio (struct nodoTurbo_S **h, void *dataPtr, int dataSize)
	\brief Inserta un nuevo nodo a la lista siemple enlazada, esta funcionando como una pila.
	\author Ing. Jerónimo F. Atencio (jerome5416@gmail.com)
	\date 2013.02.02
	\param **h Puntero al puntero de la cabeza de la lista.
	\param dataPtr Puntero a los datos a insertar en la lista.
	\param dataSize Tamaño en bytes de los datos.
	\return Retorna -1 en caso de error y setea errno, devuelve cero en caso contrario.
*/
int lseTurboInsertarInicio (struct nodoTurbo_S **h, void *dataPtr, int dataSize) {
struct nodoTurbo_S *p;
	
	//-- Pido memoria --
	p = (struct nodoTurbo_S*)malloc (sizeof (struct nodoTurbo_S));
	if (p == NULL) {
		//-- No hay memoria --
		return (-1);
	} else {
		//-- Pido memoria para los datos --
		p->dataPtr = malloc (dataSize);
		if (p->dataPtr == NULL) {
			//-- No hay memoria para los datos --
			free (p);		//-- Libero la memoria para el nodo que pedi --
			return (-2);
		} else {
			//-- Relleno la estructura --
			//-- Copio los datos --
			memcpy (p->dataPtr, dataPtr, dataSize);
			//-- Pongo el nodo al principio --
			p->sig = *h;		//-- Si es el primer nodo de la lista *h es NULL --
			*h = p;				//-- Apunto el puntero a la cabeza de la lista al  nuevo nodo --
			return (0);
		}
	}
}


/**
	\fn void lseTurboImprimir (struct nodoTurbo_S **h, void (*printFunc)(void *))
	\brief Imprime los datos de la lista.
	\author Ing. Jerónimo F. Atencio (jerome5416@gmail.com)
	\date 2013.05.02
	\param **h Puntero al puntero de la cabeza de la lista.
	\param void (*printFunc)(void *) Puntero a la función que imprime los datos.
	\return void
*/
void lseTurboImprimir (struct nodoTurbo_S **h, void (*printFunc)(void *)) {
struct nodoTurbo_S *p;

	//-- Voy recorriendo la lista e imprimiendo nodos --
	for (p = *h; p != NULL; p = p->sig) {
		printFunc (p->dataPtr);		//-- Llamo a la funcion que sabe imprimir --
	}
}


/**
	\fn void lseTurboLiberar (struct nodoTurbo_S **h)
	\brief Libera toda la lista.
	\author Ing. Jerónimo F. Atencio (jerome5416@gmail.com)
	\date 2013.05.02
	\param **h Puntero al puntero de la cabeza de la lista.
	\return void
*/
void lseTurboLiberar (struct nodoTurbo_S **h) {
struct nodoTurbo_S *p, *aux;

	if (*h == NULL) {
		//-- Lista vacia --		
		return;
	} else {
		//-- Voy recorriendo la lista y eliminando nodos --	
		for (p = *h; p != NULL;) {
			//** Debug **
			//printf ("%p\r\n", p);
			//** Debug **
			aux = p;	//-- Salvo el puntero al nodo a eliminar --
			p = p->sig;	//-- Me muevo al siguiente nodo --
			free (aux->dataPtr);	//-- Libero los datos --
			free (aux);				//-- Libero el nodo actual --
		}
		*h = p;	//-- Pongo el puntero a la cabeza de la lista en NULL --
	}
}

/**
	\fn int lseTurboContar (struct nodoTurbo_S **h)
	\brief Cuenta la cantidad de nodos de la lista.
	\author Ing. Jerónimo F. Atencio (jerome5416@gmail.com)
	\date 2013.02.02
	\param **h Puntero al puntero de la cabeza de la lista.
	\return Cantidad de nodos de la lista
	
*/
int lseTurboContar (struct nodoTurbo_S **h) {
struct nodoTurbo_S *p;
int i;

	for (p = *h, i = 0; p != NULL; p = p->sig, i++);
	return (i);
}


/**
	\fn int lseTurboInsertarFinal (struct nodoTurbo_S **h, void *dataPtr, int dataSize)
	\brief Inserta un nuevo nodo a la lista siemple enlazada, esta funcionando como una pila.
	\author Ing. Jerónimo F. Atencio (jerome5416@gmail.com)
	\date 2013.02.02
	\param **h Puntero al puntero de la cabeza de la lista.
	\param dataPtr Puntero a los datos a insertar en la lista.
	\param dataSize Tamaño en bytes de los datos.
	\return Retorna -1 en caso de error y setea errno, devuelve cero en caso contrario.
*/
int lseTurboInsertarFinal (struct nodoTurbo_S **h, void *dataPtr, int dataSize) {
struct nodoTurbo_S *p, *aux;
	
	//-- Pido memoria --
	p = (struct nodoTurbo_S*)malloc (sizeof (struct nodoTurbo_S));
	if (p == NULL) {
		//-- No hay memoria --
		return (-1);
	} else {
		p->dataPtr = malloc (dataSize);
		if (p->dataPtr == NULL) {
			//-- No hay memoria para los datos --
			free (p);		//-- Libero la memoria para el nodo que pedi --
			return (-2);
		} else {
			//-- Relleno la estructura --
			//-- Copio los datos --
			memcpy (p->dataPtr, dataPtr, dataSize);
			p->sig = NULL;
		}
		//-- Me fijo donde insertarlo --
		if (*h == NULL) {
			//-- La lista esta vacia --
			*h = p;
		} else {
			//-- Busco el último nodo --
			for (aux = *h; aux->sig != NULL; aux = aux->sig);
			//-- Inserto el nodo al final --
			aux->sig = p;
		}
		return (0);
	}
}

/**
	\fn struct nodoTurbo_S* lseTurboBuscar (struct nodoTurbo_S **h, void *dataPtr, int (*cmpFunc)(void *, void*)) {
	\brief Cuenta la cantidad de nodos de la lista.
	\author Ing. Jerónimo F. Atencio (jerome5416@gmail.com)
	\date 2013.02.02
	\param **h Puntero al puntero de la cabeza de la lista.
	\param dataPtr Puntero al dato a buscar.
	\param int (*cmpFunc)(void *, void*) Puntero a la función que compara los datos. La función devuelve 1 
	si la comparación es verdadera, 0 en caso contrario.
	\return Un puntero al elemento encontrado, NULL en caso contrario.
	
*/
struct nodoTurbo_S* lseTurboBuscar (struct nodoTurbo_S **h, void *dataPtr, int (*cmpFunc)(void *, void*)) {
struct nodoTurbo_S *p;

	//-- Recorro la lista --
	for (p = *h; p != NULL; p = p->sig) {
		if (cmpFunc (p->dataPtr, dataPtr)) {
			//-- Encontre el dato --
			return (p);
		}
	}
	//-- Si sali del for es que no encontre nada --
	return (NULL);
}

/**
	\fn int lseTurboRemover (struct nodoTurbo_S **h, void *dataPtr, int (*cmpFunc)(void *, void*))
	\brief Remueve un nodo de la lista. 
	\details Si hay dos nodos con el mismo datos, remueve solo el primero que encuentra.
	\author Ing. Jerónimo F. Atencio (jerome5416@gmail.com)
	\date 2013.02.02
	\param **h Puntero al puntero de la cabeza de la lista.
	\param dataPtr Puntero al dato a eliminar.
	\param int (*cmpFunc)(void *, void*) Puntero a la función que compara los datos. La función devuelve 1 
	\return Retorna 1 si encontro y removio el nodo en la lista, 0 en caso contrario
*/
int lseTurboRemover (struct nodoTurbo_S **h, void *dataPtr, int (*cmpFunc)(void *, void*)) {
struct nodoTurbo_S *p, *aux;

	//-- Me fijo si hay algo en la lista --
	if (*h != NULL) {
		//-- Busco el nodo a eliminar --
		for (p = *h, aux = NULL; p != NULL; aux = p, p = p->sig){
			if (cmpFunc (p->dataPtr, dataPtr)) {
				//-- Encontre el dato --
				if (aux == NULL) {
					//-- Es el primer nodo --
					*h = p->sig;
				} else {
					aux->sig = p->sig;
				}
				free (p);
				return (1);
			}
		}
	} else {
		//-- Lista vacia --
		return (0);
	}
	return (0);
}
