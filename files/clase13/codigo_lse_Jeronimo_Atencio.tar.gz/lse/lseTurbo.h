/**
	\file lseTurbo.h
	\brief API de listas simple enlazadas
	\author Ing. Jerónimo F. Atencio (jerome5416@gmail.com)
	\date 2010.05.02
	\version 1.0.0
*/
//----------
#ifndef LSE_TURBO_H
#define LSE_TURBO_H

/** \struct nodoTurbo_S 
	\brief Estructura del nodo de la lista simple enlazada.
*/
struct nodoTurbo_S {
	void *dataPtr;				//!< Datos.
	struct nodoTurbo_S *sig;	//!< Puntero al siguiente nodo.
};

//----------------
//-- Prototipos --
//----------------
int lseTurboInsertarInicio (struct nodoTurbo_S **h, void *dataPtr, int dataSize);
void lseTurboImprimir (struct nodoTurbo_S **h, void (*func)(void *));
void lseTurboLiberar (struct nodoTurbo_S **h);
int lseTurboContar (struct nodoTurbo_S **h);
int lseTurboInsertarFinal (struct nodoTurbo_S **h, void *dataPtr, int dataSize);
struct nodoTurbo_S* lseTurboBuscar (struct nodoTurbo_S **h, void *dataPtr, int (*cmpFunc)(void *, void*));
int lseTurboRemover (struct nodoTurbo_S **h, void *dataPtr, int (*cmpFunc)(void *, void*));

#endif
