/**
	\file lse.h
	\brief API de listas simple enlazadas. 
	\author Ing. Jerónimo F. Atencio (jerome5416@gmail.com)
	\date 2010.05.02
	\version 1.0.0
*/
//----------
#ifndef LSE_H
#define LSE_H

/** \struct nodo_S 
	\brief Estructura del nodo de la lista simple enlazada.
*/
struct nodo_S {
	int data;				//!< Datos.
	struct nodo_S *sig;		//!< Puntero al siguiente nodo.
};

//----------------
//-- Prototipos --
//----------------
int lseInsertarInicio (struct nodo_S **h, int data);
void lseImprimir (struct nodo_S **h);
void lseLiberar (struct nodo_S **h);
int lseContar (struct nodo_S **h);
int lseInsertarFinal (struct nodo_S **h, int data);
struct nodo_S* lseBuscar (struct nodo_S **h, int data);
int lseRemover (struct nodo_S **h, int data);

#endif
