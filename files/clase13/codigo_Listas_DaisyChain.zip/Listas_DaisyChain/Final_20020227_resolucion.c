/**************************************************************************
Se dispone de un archivo en donde estan registrados los nombres de los
visitantes de una biblioteca dia a dia. Los datos entan almacenados(d/m/a)
un byte por digito y a continuaci�n los nombres (string- separados por un
enter entre cada uno) de los visitantes de ese d�a. Puede haber visitantes
repetidos en un mismo dia. Luego viene otro d�a y as� hasa terminar el
archivo.
Imprimir el nombre de la persona que visito mas dias la biblioteca (se la
concidera unica) y los dias en que concurrio. (contavilizar una visita
diaria).

NOTA: se supone que los string no superan los 256bytes.
**************************************************************************/
#include<conio.h>
#include<dos.h>
#include<string.h>
#include<stdio.h>
#include<stdlib.h>
#include<alloc.h>

struct datos{
						char 					tipo;
						char					fecha[11];
						char					nombre[256];
						};

struct fecha {
						char					fecha[11];
						int 					cant;
						struct fecha	*sig;
						};
struct lista{
						char					*nombre;
						int 					cant;
						struct fecha 	*inicio;
						struct lista	*sig;
						};

#define FECHA     0
#define VISITANTE 1

void cargar_archivo(struct lista**);
void mostrar(struct lista**);
void leer_datos(FILE **, struct datos*);
void borrar(struct lista**);

void main(void)
{
struct lista *inicio=NULL;
cargar_archivo(&inicio);
mostrar(&inicio);
getch();
borrar(&inicio);
}

void leer_datos(FILE **BD, struct datos *dato)
{
char c;
char aux[256];
c=fgetc(*BD);
	if(c<65)//FECHA
	{
		dato->fecha[0]=(char)c;
		dato->fecha[1]=(char)fgetc(*BD);
		dato->fecha[2]='/';
		dato->fecha[3]=(char)fgetc(*BD);
		dato->fecha[4]=(char)fgetc(*BD);
		dato->fecha[5]='/';
		dato->fecha[6]='2';
		dato->fecha[7]='0';
		dato->fecha[8]=(char)fgetc(*BD);
		dato->fecha[9]=(char)fgetc(*BD);
		dato->fecha[10]=0;
		dato->tipo=FECHA;
	}
	else
	{
		dato->nombre[0]=c;
		dato->nombre[1]=0;
		fgets(aux,256,*BD);
		aux[strlen(aux)-2]=0;
		strcat(dato->nombre,aux);
		dato->tipo=VISITANTE;
	}
}



void cargar_archivo(struct lista **inicio)
{
struct lista *act_v=NULL;
struct lista *ant_v=NULL;
struct lista *aux_v=NULL;
struct fecha *act_f=NULL;
struct fecha *ant_f=NULL;
struct fecha *aux_f=NULL;

FILE *BD;
struct datos dato;

BD=fopen("C:\\biblio.txt","rb");
if(BD)
{
	while(!feof(BD))
	{
		leer_datos(&BD,&dato);
		if(dato.tipo==VISITANTE)
		{
			aux_v=(struct lista*)malloc(sizeof(struct lista));
			if(aux_v)
			{
				aux_v->cant=1;
				aux_v->nombre=(char*)malloc(sizeof(char)*strlen(dato.nombre));
				strcpy(aux_v->nombre,dato.nombre);
				aux_v->inicio=(struct fecha*)malloc(sizeof(struct fecha));
				aux_v->sig=NULL;
				if(aux_v->inicio)
				{
					strcpy(aux_v->inicio->fecha,dato.fecha);
					aux_v->inicio->cant=1;
					aux_v->inicio->sig=NULL;
				}

				if(!*inicio)//si es el 1� NODO
					*inicio=aux_v;
				else
				{
					act_v=*inicio;
					ant_v=*inicio;
					while(act_v&&strcmp(act_v->nombre,aux_v->nombre))
					{
						ant_v=act_v;
						act_v=act_v->sig;
					}

					if(!act_v)//Si no existe, se lo ingresa al final
						ant_v->sig=aux_v;
					else
					{//Si existe libero aux_v y creo un nodo del tipo fecha para incorporarlo a la sublisa.
						free(aux_v->inicio);
						free(aux_v->nombre);
						free(aux_v);
						ant_f=act_v->inicio;
						act_f=act_v->inicio;
						while(act_f&&strcmp(dato.fecha,act_f->fecha))
						{
							ant_f=act_f;
							act_f=act_f->sig;
						}

						if(!act_f)
						{
							aux_f=(struct fecha*)malloc(sizeof(struct fecha));
							if(aux_f)
							{
								ant_f->sig=aux_f;
								aux_f->cant=1;
								aux_f->sig=NULL;
								strcpy(aux_f->fecha,dato.fecha);
								act_v->cant++;//cantdidad de dias por visitante
							}
						}
						else
							act_f->cant++;//cantidad de visitas por dia
					}
				}
			}
		}
	}
	fclose(BD);
}

}

void mostrar(struct lista **inicio)
{
struct lista *act_v=*inicio;
struct fecha *act_f=NULL;
char nombre[256];
int cant;


clrscr();
cant=act_v->cant;
act_f=act_v->inicio;
strcpy(nombre,act_v->nombre);

while(act_v)
{
	if(act_v->cant>cant)
	{
		cant=act_v->cant;
		act_f=act_v->inicio;
		strcpy(nombre,act_v->nombre);
	}
	act_v=act_v->sig;
}
printf("La persona que m�s dias visito fue: %s con %d visitas\n",nombre,cant);
while(act_f)
{
printf("\n\tEl dia %s visito la biblioteca %d veces",act_f->fecha,act_f->cant);
act_f=act_f->sig;
}

}

void borrar(struct lista **inicio)
{
struct lista *ant_v=*inicio;
struct lista *act_v=ant_v->sig;
struct fecha *ant_f=(*inicio)->inicio;
struct fecha *act_f=ant_f->sig;

while(act_v)
{
ant_v=act_v;
act_v=act_v->sig;
	while(act_f)
	{
	ant_f=act_f;
	act_f=act_f->sig;
	free(act_f);
	}
free(act_v->nombre);
free(act_v->inicio);
free(act_v);
}
free((*inicio)->inicio);
free(*inicio);
}