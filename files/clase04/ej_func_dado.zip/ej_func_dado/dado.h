/*
 *  dado.h
 *
 *  Ejercicio 3.3
 *
 *  Autor: Leandro Beretta <lea.beretta@gmail.com>
 *
 *  Informática I - UTN.BA
 *
 */ 

#define		TRUE				1
#define		FALSE				0
#define 	CLEAR 				"clear"
#define 	TITULO 				"Ejemplo de rand()\n"
#define 	VALOR_MAX_DADO		6
#define		VALOR_MIN_DADO		2
#define		EXPLICAR_MODULO		FALSE

/* Prototipos de las funciones */

int tirarDado(); 
