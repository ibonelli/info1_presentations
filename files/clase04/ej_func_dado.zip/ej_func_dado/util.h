/*
 *  util.h
 *
 *  Ejercicio 3.3
 *
 *  Autor: Leandro Beretta <lea.beretta@gmail.com>
 *
 *  Informática I - UTN.BA
 *
 */  

int generarValorAleatorio(int valorMin, int valorMax);
