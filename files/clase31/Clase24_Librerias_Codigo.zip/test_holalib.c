/*
 * Programa de prueba 
 * para nuestra Biblioteca holalib
 * 
 * Compilar: gcc -c -otest_holalib.o test_holalib.c
 * 
 */

#include "holalib.h"

int main(void)
{
	hola();
	return 0;
}
