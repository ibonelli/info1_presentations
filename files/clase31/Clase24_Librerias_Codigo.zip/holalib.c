/* 
 * Ejemplo para generar una Biblioteca
 * Funcion: hola()
 * Imprime en stdout: Hola Mundo!
 */

#include "holalib.h"
void hola(void)
{
	printf("Hola Mundo!\n");
}
